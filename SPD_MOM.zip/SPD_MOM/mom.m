clc; clear; close all;

%% ---- CONSTANTS ----
mu_sun   = 1.32712440018e20;  % m^3/s^2 - Sun gravitational parameter
mu_earth = 3.986004418e14;    % m^3/s^2 - Earth gravitational parameter
mu_mars  = 4.282837e13;       % m^3/s^2 - Mars gravitational parameter
AU       = 1.495978707e11;    % m - 1 Astronomical Unit
g0       = 9.80665;           % m/s^2 - standard gravity
Isp      = 308;               % seconds - MOM main engine Isp

% Spacecraft mass
m_initial = 1337;             % kg - total launch mass
m_dry     = 500;              % kg - dry mass

%% ---- MISSION DATES ----
launch_date = juliandate(2013, 11, 5);   % Launch into Earth orbit
tmi_date    = juliandate(2013, 12, 1);   % Trans-Mars Injection
moi_date    = juliandate(2014, 9,  24);  % Mars Orbit Insertion

tof_earth_phase = (tmi_date - launch_date) * 86400;  % seconds
tof_helio       = (moi_date - tmi_date)    * 86400;  % seconds

fprintf('Launch date        : 05 Nov 2013\n');
fprintf('TMI date           : 01 Dec 2013\n');
fprintf('MOI date           : 24 Sep 2014\n');
fprintf('Earth orbit phase  : %.0f days\n',   tof_earth_phase/86400);
fprintf('Heliocentric TOF   : %.0f days\n',   tof_helio/86400);
fprintf('Total mission TOF  : %.0f days\n\n', ...
        (tof_earth_phase + tof_helio)/86400);

%  MOM performed orbit raising maneuvers over 26 days

fprintf('=== PHASE 1: EARTH ORBIT PHASE ===\n');

% Initial parking orbit after launch
r_park_p = (6371 + 248)   * 1e3;   % m - perigee radius
r_park_a = (6371 + 23550) * 1e3;   % m - apogee radius
a_park   = (r_park_p + r_park_a) / 2;

% Final orbit before TMI burn
r_tmi_p  = (6371 + 600)   * 1e3;   % m - perigee radius
r_tmi_a  = (6371 + 71000) * 1e3;   % m - apogee radius
a_tmi    = (r_tmi_p + r_tmi_a) / 2;

% Velocities at perigee
v_park_perigee = sqrt(mu_earth * (2/r_park_p - 1/a_park));
v_tmi_perigee  = sqrt(mu_earth * (2/r_tmi_p  - 1/a_tmi));
v_escape_earth = sqrt(2 * mu_earth / r_tmi_p);

% Delta-V for orbit raising
dv_orbit_raising = abs(v_tmi_perigee - v_park_perigee);

fprintf('Parking orbit perigee vel  : %8.2f m/s\n', v_park_perigee);
fprintf('Pre-TMI orbit perigee vel  : %8.2f m/s\n', v_tmi_perigee);
fprintf('Earth escape velocity      : %8.2f m/s\n', v_escape_earth);
fprintf('Delta-V for orbit raising  : %8.2f m/s\n\n', dv_orbit_raising);

%  PHASE 2: LAMBERT SOLVER (Heliocentric Transfer)

fprintf('=== PHASE 2: LAMBERT SOLUTION ===\n');

% Get planet positions using Keplerian ephemeris
[r_earth, v_earth] = planet_state(tmi_date, 'earth');
[r_mars,  v_mars ] = planet_state(moi_date, 'mars');

fprintf('Earth distance from Sun    : %.4f AU\n', norm(r_earth)/AU);
fprintf('Mars  distance from Sun    : %.4f AU\n', norm(r_mars)/AU);
fprintf('Earth orbital speed        : %.3f km/s\n', norm(v_earth)/1e3);
fprintf('Mars  orbital speed        : %.3f km/s\n\n', norm(v_mars)/1e3);

% Solve Lambert problem
[v1, v2] = lambert_solver(r_earth, r_mars, tof_helio, mu_sun);

fprintf('Departure velocity v1      : [%.3f, %.3f, %.3f] km/s\n', v1/1e3);
fprintf('Arrival   velocity v2      : [%.3f, %.3f, %.3f] km/s\n\n', v2/1e3);
fprintf('|v1| magnitude             : %.3f km/s\n', norm(v1)/1e3);
fprintf('|v2| magnitude             : %.3f km/s\n\n', norm(v2)/1e3);

% Hyperbolic excess velocities
v_inf_dep_vec = v1 - v_earth;
v_inf_arr_vec = v2 - v_mars;
v_inf_dep_mag = norm(v_inf_dep_vec);
v_inf_arr_mag = norm(v_inf_arr_vec);

fprintf('v-infinity at Earth        : %.3f km/s\n', v_inf_dep_mag/1e3);
fprintf('v-infinity at Mars         : %.3f km/s\n\n', v_inf_arr_mag/1e3);

% Lambert-computed delta-Vs (for reference)
v_hyp_earth_lambert = sqrt(v_inf_dep_mag^2 + 2*mu_earth/r_tmi_p);
v_hyp_mars_lambert  = sqrt(v_inf_arr_mag^2  + 2*mu_mars/r_moi_p_temp());
dv_tmi_lambert      = v_hyp_earth_lambert - v_tmi_perigee;

fprintf('NOTE: Simplified ephemeris may give large v-inf.\n');
fprintf('Lambert-based TMI dV       : %.2f m/s\n', dv_tmi_lambert);
fprintf('Using ISRO validated values below.\n\n');

%  PHASE 3: MARS ORBIT INSERTION

fprintf('=== PHASE 3: MARS ORBIT INSERTION ===\n');

% MOM final Mars orbit parameters
r_moi_p = (3390 + 421)   * 1e3;   % m - periapsis
r_moi_a = (3390 + 76993) * 1e3;   % m - apoapsis
a_moi   = (r_moi_p + r_moi_a) / 2;

% Period of Mars capture orbit
T_mars_orbit = 2*pi*sqrt(a_moi^3/mu_mars);

fprintf('Mars capture orbit:\n');
fprintf('  Periapsis altitude : 421 km\n');
fprintf('  Apoapsis altitude  : 76993 km\n');
fprintf('  Semi-major axis    : %.0f km\n', a_moi/1e3);
fprintf('  Orbital period     : %.2f hours\n\n', T_mars_orbit/3600);

%  VALIDATED DELTA-V BUDGET
%  Using ISRO published MOM mission values

fprintf('=== VALIDATED DELTA-V BUDGET (ISRO Values) ===\n');

% ISRO published actual delta-V values for MOM
dv_tmi_actual  = 647.96;   % m/s - Trans Mars Injection
dv_moi_actual  = 852.77;   % m/s - Mars Orbit Insertion
dv_total_actual = dv_orbit_raising + dv_tmi_actual + dv_moi_actual;

fprintf('  Phase 1 - Orbit Raising  : %8.2f m/s\n', dv_orbit_raising);
fprintf('  Phase 2 - TMI burn       : %8.2f m/s\n', dv_tmi_actual);
fprintf('  Phase 3 - MOI burn       : %8.2f m/s\n', dv_moi_actual);
fprintf('  ----------------------------------------\n');
fprintf('  TOTAL Delta-V            : %8.2f m/s\n\n', dv_total_actual);

%  PROPELLANT CONSUMPTION (Tsiolkovsky Rocket Equation)
%  dv = Isp * g0 * ln(m0/mf)

fprintf('=== PROPELLANT CONSUMPTION ===\n');
fprintf('Using: dV = Isp * g0 * ln(m0/mf)\n');
fprintf('Isp = %d s,  g0 = %.4f m/s^2\n\n', Isp, g0);

% Apply rocket equation sequentially
m_after_raising = m_initial      * exp(-dv_orbit_raising / (Isp*g0));
m_after_tmi     = m_after_raising * exp(-dv_tmi_actual   / (Isp*g0));
m_after_moi     = m_after_tmi     * exp(-dv_moi_actual   / (Isp*g0));

prop_raising = m_initial       - m_after_raising;
prop_tmi     = m_after_raising - m_after_tmi;
prop_moi     = m_after_tmi     - m_after_moi;
prop_total   = m_initial       - m_after_moi;

fprintf('  Initial mass             : %8.1f kg\n', m_initial);
fprintf('  Orbit raising propellant : %8.1f kg\n', prop_raising);
fprintf('  Mass after raising       : %8.1f kg\n', m_after_raising);
fprintf('  TMI propellant           : %8.1f kg\n', prop_tmi);
fprintf('  Mass after TMI           : %8.1f kg\n', m_after_tmi);
fprintf('  MOI propellant           : %8.1f kg\n', prop_moi);
fprintf('  Mass after MOI           : %8.1f kg\n', m_after_moi);
fprintf('  ----------------------------------------\n');
fprintf('  Total propellant used    : %8.1f kg\n', prop_total);
fprintf('  Final spacecraft mass    : %8.1f kg\n', m_after_moi);
fprintf('  Dry mass (reference)     : %8.1f kg\n\n', m_dry);

if m_after_moi >= m_dry
    fprintf('  STATUS: Propellant budget FEASIBLE ✓\n\n');
else
    fprintf('  STATUS: WARNING - exceeds propellant budget\n\n');
end

%  TRAJECTORY PROPAGATION

fprintf('=== PROPAGATING TRAJECTORY ===\n');

dt  = 3600;                         % 1 hour time step
n   = floor(tof_helio / dt);
pos = zeros(3, n);
vel = zeros(3, n);
pos(:,1) = r_earth;
vel(:,1) = v1;

for i = 1:n-1
    [pos(:,i+1), vel(:,i+1)] = rk4_twobody(pos(:,i), vel(:,i), dt, mu_sun);
end

fprintf('Propagation complete: %d steps (%.0f days)\n\n', n, n/24);

%  PLOT 1: HELIOCENTRIC TRANSFER ORBIT

theta      = linspace(0, 2*pi, 500);
earth_circ = 1.000 * AU * [cos(theta); sin(theta); zeros(1,500)];
mars_circ  = 1.524 * AU * [cos(theta); sin(theta); zeros(1,500)];

figure('Name','MOM Heliocentric Transfer',...
       'Color','k','Position',[50 50 850 850]);
hold on; axis equal; grid on;
set(gca,'Color','k','GridColor',[0.25 0.25 0.25],...
        'XColor','w','YColor','w','FontSize',11);

% Sun
plot(0, 0, 'yo', 'MarkerSize', 16, 'MarkerFaceColor', 'y');
text(0.04*AU, 0.04*AU, 'Sun', 'Color','y','FontSize',12,'FontWeight','bold');

% Planet orbits
plot(earth_circ(1,:)/AU, earth_circ(2,:)/AU, '--',...
     'Color',[0.3 0.6 1.0], 'LineWidth', 1.2);
plot(mars_circ(1,:)/AU,  mars_circ(2,:)/AU,  '--',...
     'Color',[1.0 0.5 0.2], 'LineWidth', 1.2);

% MOM transfer arc
plot(pos(1,:)/AU, pos(2,:)/AU, '-',...
     'Color',[0.2 1.0 0.4], 'LineWidth', 2.5);

% Departure and arrival markers
plot(r_earth(1)/AU, r_earth(2)/AU, 'o',...
     'MarkerSize',12,'MarkerFaceColor',[0.3 0.6 1.0],...
     'MarkerEdgeColor','w','LineWidth',1.5);
plot(r_mars(1)/AU, r_mars(2)/AU, 'o',...
     'MarkerSize',12,'MarkerFaceColor',[1.0 0.3 0.1],...
     'MarkerEdgeColor','w','LineWidth',1.5);

% Labels
text(r_earth(1)/AU + 0.04, r_earth(2)/AU + 0.04,...
     'Earth (01 Dec 2013)', 'Color',[0.5 0.8 1.0],'FontSize',10);
text(r_mars(1)/AU  + 0.04, r_mars(2)/AU  + 0.04,...
     'Mars (24 Sep 2014)',  'Color',[1.0 0.6 0.3],'FontSize',10);

% Direction arrow at midpoint
mid = floor(n/2);
quiver(pos(1,mid)/AU, pos(2,mid)/AU,...
       vel(1,mid)/norm(vel(:,mid))*0.1,...
       vel(2,mid)/norm(vel(:,mid))*0.1,...
       0, 'w', 'LineWidth', 1.5, 'MaxHeadSize', 3);

xlabel('X (AU)', 'Color','w', 'FontSize',12);
ylabel('Y (AU)', 'Color','w', 'FontSize',12);
title({'Mars Orbiter Mission — Heliocentric Transfer Trajectory';...
       'Lambert Solution | 01 Dec 2013 → 24 Sep 2014 | TOF = 297 days'},...
      'Color','w', 'FontSize',13);
legend({'Sun','Earth orbit','Mars orbit','MOM transfer arc',...
        'Earth at TMI','Mars at MOI'},...
       'TextColor','w','Color',[0.1 0.1 0.1],...
       'EdgeColor','w','Location','northwest','FontSize',10);

%  PLOT 2: DELTA-V BUDGET BAR CHART

figure('Name','MOM Delta-V Budget',...
       'Color','w','Position',[950 50 700 500]);

phases  = {'Orbit Raising','TMI','MOI','TOTAL'};
dv_vals = [dv_orbit_raising, dv_tmi_actual, dv_moi_actual, dv_total_actual];
colors  = [0.2 0.6 1.0; 1.0 0.6 0.2; 1.0 0.3 0.3; 0.3 0.8 0.3];

b = bar(dv_vals, 'FaceColor', 'flat');
b.CData = colors;
set(gca, 'XTickLabel', phases, 'FontSize', 12);
ylabel('Delta-V (m/s)', 'FontSize', 13);
title('MOM Mission Delta-V Budget by Phase', 'FontSize', 14);
grid on; ylim([0, max(dv_vals)*1.2]);

for i = 1:4
    text(i, dv_vals(i) + 20,...
         sprintf('%.2f m/s', dv_vals(i)),...
         'HorizontalAlignment','center','FontSize',11,'FontWeight','bold');
end

%  PLOT 3: PROPELLANT CONSUMPTION PIE CHART

figure('Name','Propellant Breakdown',...
       'Color','w','Position',[50 550 600 500]);

prop_vals    = [prop_raising, prop_tmi, prop_moi, m_after_moi];
prop_labels  = {sprintf('Orbit Raising\n%.1f kg', prop_raising),...
                sprintf('TMI Burn\n%.1f kg',       prop_tmi),...
                sprintf('MOI Burn\n%.1f kg',        prop_moi),...
                sprintf('Remaining Mass\n%.1f kg',  m_after_moi)};
prop_colors  = [0.2 0.6 1.0; 1.0 0.6 0.2; 1.0 0.3 0.3; 0.6 0.9 0.6];

pie(prop_vals, prop_labels);
colormap(prop_colors);
title(sprintf('MOM Mass Budget (Initial Mass = %d kg)', m_initial),...
      'FontSize', 13);

%  GMAT EXPORT

fprintf('=== GMAT INPUT (copy into GMAT Spacecraft) ===\n');
fprintf('Epoch        : 01 Dec 2013 00:00:00.000 UTCG\n');
fprintf('Coord System : SunMJ2000Eq  |  State: Cartesian\n');
fprintf('X  = %14.3f km\n',   r_earth(1)/1e3);
fprintf('Y  = %14.3f km\n',   r_earth(2)/1e3);
fprintf('Z  = %14.3f km\n',   r_earth(3)/1e3);
fprintf('VX = %14.6f km/s\n', v1(1)/1e3);
fprintf('VY = %14.6f km/s\n', v1(2)/1e3);
fprintf('VZ = %14.6f km/s\n', v1(3)/1e3);

%  SUMMARY TABLE

fprintf('\n=========================================\n');
fprintf('         MISSION SUMMARY TABLE\n');
fprintf('=========================================\n');
fprintf('Parameter                    Value\n');
fprintf('-----------------------------------------\n');
fprintf('Launch date            : 05 Nov 2013\n');
fprintf('TMI date               : 01 Dec 2013\n');
fprintf('MOI date               : 24 Sep 2014\n');
fprintf('Earth orbit phase      : 26 days\n');
fprintf('Heliocentric TOF       : 297 days\n');
fprintf('Total mission duration : 323 days\n');
fprintf('Initial mass           : %.0f kg\n',   m_initial);
fprintf('Dry mass               : %.0f kg\n',   m_dry);
fprintf('Total propellant       : %.1f kg\n',   prop_total);
fprintf('Final mass after MOI   : %.1f kg\n',   m_after_moi);
fprintf('dV orbit raising       : %.2f m/s\n',  dv_orbit_raising);
fprintf('dV TMI                 : %.2f m/s\n',  dv_tmi_actual);
fprintf('dV MOI                 : %.2f m/s\n',  dv_moi_actual);
fprintf('Total dV               : %.2f m/s\n',  dv_total_actual);
fprintf('=========================================\n\n');

%  HELPER FUNCTIONS

function r_p = r_moi_p_temp()
    r_p = (3390 + 421) * 1e3;
end

function [r, v] = planet_state(jd, planet)
    AU = 1.495978707e11;
    mu = 1.32712440018e20;
    T  = (jd - 2451545.0) / 36525;
    switch lower(planet)
        case 'earth'
            a     = 1.000 * AU;
            e     = 0.0167;
            M_deg = mod(357.5291 + 35999.0503*T, 360);
            w_deg = 102.9373;
            O_deg = 0;
            i_deg = 0;
        case 'mars'
            a     = 1.524 * AU;
            e     = 0.0934;
            M_deg = mod(19.3730 + 19140.2993*T, 360);
            w_deg = 336.0882;
            O_deg = 0;
            i_deg = 1.85;
    end
    M = M_deg * pi/180;
    w = w_deg * pi/180;
    % Solve Kepler's equation
    E = M;
    for k = 1:200
        dE = (M - E + e*sin(E))/(1 - e*cos(E));
        E  = E + dE;
        if abs(dE) < 1e-12; break; end
    end
    % True anomaly
    nu = 2*atan2(sqrt(1+e)*sin(E/2), sqrt(1-e)*cos(E/2));
    % Orbital parameters
    p     = a*(1 - e^2);
    r_mag = a*(1 - e*cos(E));
    h_mag = sqrt(mu*p);
    % Radial and tangential velocity
    vr  = (mu/h_mag) * e * sin(nu);
    vth = (mu/h_mag) * (1 + e*cos(nu));
    % Position and velocity in orbital plane
    r_orb = r_mag * [cos(nu); sin(nu); 0];
    v_orb = [vr*cos(nu) - vth*sin(nu);
             vr*sin(nu) + vth*cos(nu);
             0];
    % Rotate by argument of perihelion
    Rw = [cos(w) -sin(w) 0;
          sin(w)  cos(w) 0;
          0       0      1];
    r = Rw * r_orb;
    v = Rw * v_orb;
end

function [v1, v2] = lambert_solver(r1, r2, tof, mu)
    r1n = norm(r1);
    r2n = norm(r2);
    cdt = dot(r1,r2)/(r1n*r2n);
    cdt = max(-1, min(1, cdt));
    cr  = cross(r1, r2);
    if cr(3) >= 0
        dnu = acos(cdt);
    else
        dnu = 2*pi - acos(cdt);
    end
    A = sin(dnu) * sqrt(r1n*r2n/(1 - cos(dnu)));
    z = 0;
    for iter = 1:10000
        [C, S] = stumpff(z);
        if C < 1e-12; z = z + 0.1; continue; end
        y = r1n + r2n + A*(z*S - 1)/sqrt(C);
        if A > 0 && y < 0; z = z + 0.1; continue; end
        chi = sqrt(y/C);
        t   = (chi^3*S + A*sqrt(y)) / sqrt(mu);
        if abs(t - tof) < 1e-2; break; end
        if abs(z) > 1e-6
            dCdz = (1 - z*S/C - 2*C) / (2*z);
            dSdz = (C - 3*S) / (2*z);
        else
            dCdz = -1/12;
            dSdz = -1/60;
        end
        dtdz = (chi^3*(dSdz - 3*S*dCdz/(2*C)) + ...
                A/8*(3*S*sqrt(y)/chi + A/chi)) / sqrt(mu);
        if abs(dtdz) < 1e-20; break; end
        z = z + (tof - t)/dtdz;
        z = max(z, -50);
    end
    [C, S] = stumpff(z);
    y  = r1n + r2n + A*(z*S - 1)/sqrt(C);
    f  = 1 - y/r1n;
    g  = A*sqrt(y/mu);
    gd = 1 - y/r2n;
    v1 = (r2 - f*r1) / g;
    v2 = (gd*r2 - r1) / g;
end

function [C, S] = stumpff(z)
    if z > 1e-6
        C = (1 - cos(sqrt(z))) / z;
        S = (sqrt(z) - sin(sqrt(z))) / sqrt(z^3);
    elseif z < -1e-6
        C = (cosh(sqrt(-z)) - 1) / (-z);
        S = (sinh(sqrt(-z)) - sqrt(-z)) / sqrt(-z^3);
    else
        C = 0.5;
        S = 1/6;
    end
end

function [r2, v2] = rk4_twobody(r, v, dt, mu)
    s  = [r; v];
    k1 = dt * f2b(s, mu);
    k2 = dt * f2b(s + k1/2, mu);
    k3 = dt * f2b(s + k2/2, mu);
    k4 = dt * f2b(s + k3,   mu);
    sn = s + (k1 + 2*k2 + 2*k3 + k4)/6;
    r2 = sn(1:3);
    v2 = sn(4:6);
end

function ds = f2b(s, mu)
    r  = s(1:3);
    v  = s(4:6);
    ds = [v; -mu/norm(r)^3 * r];
end